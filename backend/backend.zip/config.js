module.exports = {
    port: process.env.port,
    mongoUri: "mongodb+srv://guptashivangi636:PrwPh7YRB8QYpsyd@jobcamapi.29yfned.mongodb.net/jobcamapi?retryWrites=true&w=majority&appName=jobcamapi"
}