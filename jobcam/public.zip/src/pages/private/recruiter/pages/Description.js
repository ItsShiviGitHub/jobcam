import React from 'react'

const Description = () => {
    return (
        <div>Description</div>
    )
}

export default Description