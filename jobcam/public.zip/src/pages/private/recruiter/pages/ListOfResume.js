import React from 'react'

const ListOfResume = () => {
    return (
        <div>ListOfResume</div>
    )
}

export default ListOfResume