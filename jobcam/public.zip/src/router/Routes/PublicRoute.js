import React from 'react'

const PublicRoute = () => {
    return (
        <div>PublicRoute</div>
    )
}

export default PublicRoute